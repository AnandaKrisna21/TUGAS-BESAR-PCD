
# Optical Mark Recognition OPENCV



[![Watch Video](https://github.com/murtazahassan/Optical-Mark-Recognition-OPENCV/blob/master/Thumbnail.jpg)](https://youtu.be/0IqCOPlGBTs)

In this video we are going to learn how to create Optical Mark recognition algorithm in python using opencv . We will write the code from scratch going step by step while discussing the details of each line. We will use the webcam to automatically find the grades of MCQs. 

###########################################

Digits Classification using Convolution Neural Network

https://youtu.be/y1ZrOs9s2QA

###########################################


Like --- Comment --- Share 

Subscribe its FREE !!! 😂😂😂


#OMR
#OPENCV 
#PYTHON

Links:

Recommend Webcam for Computer Vision:

https://amzn.to/2MNtVKZ

Budget Webcam:

https://amzn.to/2ZP47Ug


Video Links:
Classify Traffic Signs: https://youtu.be/SWaYRyi0TTs

Classit Digits: https://youtu.be/y1ZrOs9s2QA

How To Install OPENCV in Python:https://youtu.be/CJXIjApHYVs

Computer Vision Course:
https://www.youtube.com/watch?v=CJXIj...

5 Must Know OpencCV Functions:
https://youtu.be/7kHhz7nkpBw

Easy Object Following Robot using Arduino and PixyCam:
https://youtu.be/w_krOCBk1DE

Robot Arm Arduino Tutorial | Gesture Controlled:
https://youtu.be/gmz7eOB-tCg
